"""Generates the colour IEEE figures for the HOMEOSTASIS paper from results/raw_results.csv.
Colours are colour-blind safe (Okabe-Ito); markers and line styles are kept so the figures stay legible in greyscale print."""
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from pathlib import Path

ROOT = Path(__file__).parent; OUT = ROOT / "paper_figs"; OUT.mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "Liberation Serif", "font.size": 8, "axes.linewidth": 0.6,
                     "axes.labelsize": 8, "legend.fontsize": 7, "xtick.labelsize": 7, "ytick.labelsize": 7,
                     "pdf.fonttype": 42, "ps.fonttype": 42, "mathtext.fontset": "stix"})
df = pd.read_csv(ROOT / "results" / "raw_results.csv")
C_A0, C_A2, C_A3, C_A4 = "#D55E00", "#0072B2", "#009E73", "#CC79A7"   # vermillion, blue, green, purple-pink
STY = {"A0": dict(color=C_A0, ls="-",  marker="o", label="A0/A1 (no control)"),
       "A2": dict(color=C_A2, ls="--", marker="s", label="A2 (control only)"),
       "A3": dict(color=C_A3, ls="-.", marker="^", label="A3 (HOMEOSTASIS)"),
       "A4": dict(color=C_A4, ls=":",  marker="D", label="A4 (A3, 40% watermark survival)")}

def save(fig, name):
    fig.savefig(OUT / f"{name}.pdf", bbox_inches="tight"); fig.savefig(OUT / f"{name}.png", dpi=600, bbox_inches="tight"); plt.close(fig)

def traj(metric, ylabel, name, hline=None, arms=("A0", "A2", "A3", "A4"), legend_loc="best"):
    fig, ax = plt.subplots(figsize=(3.45, 2.35))
    for a in arms:
        g = df[df.arm == a].groupby("t")[metric]
        m, s, n = g.mean(), g.std(ddof=1), g.count()
        ci = 1.96 * s / np.sqrt(n); st = STY[a]
        ax.plot(m.index, m.values, color=st["color"], ls=st["ls"], marker=st["marker"], ms=3.0, lw=1.2, label=st["label"], markevery=2)
        ax.fill_between(m.index, m - ci, m + ci, color=st["color"], alpha=0.18, lw=0)
    if hline is not None:
        ax.axhline(hline[0], color="#444444", lw=0.8, ls=(0, (1, 2))); ax.text(20.2, hline[0], hline[1], va="center", fontsize=7)
    ax.set_xlabel("Generation $t$"); ax.set_ylabel(ylabel); ax.set_xlim(1, 20); ax.set_xticks([1, 5, 10, 15, 20])
    ax.grid(True, lw=0.3, color="0.85"); ax.legend(frameon=False, loc=legend_loc, handlelength=2.6)
    for s in ("top", "right"): ax.spines[s].set_visible(False)
    save(fig, name)

traj("risk", "Collapse risk $R_t$", "fig_risk", hline=(0.35, r"$\tau$"), legend_loc="upper left")
traj("tail_coverage", "Tail coverage", "fig_tail", legend_loc="lower left")

# lambda trajectory
fig, ax = plt.subplots(figsize=(3.45, 2.35))
for a in ("A0", "A2", "A3", "A4"):
    m = df[df.arm == a].groupby("t")["lam"].mean(); st = STY[a]
    ax.plot(m.index, m.values, color=st["color"], ls=st["ls"], marker=st["marker"], ms=3.0, lw=1.2, label=st["label"], markevery=2)
ax.set_xlabel("Generation $t$"); ax.set_ylabel(r"Human-data fraction $\lambda_t$"); ax.set_xlim(1, 20); ax.set_ylim(0, 1.05)
ax.set_xticks([1, 5, 10, 15, 20]); ax.grid(True, lw=0.3, color="0.85"); ax.legend(frameon=False, loc="center right", handlelength=2.6)
for s in ("top", "right"): ax.spines[s].set_visible(False)
save(fig, "fig_lambda")

# tau sensitivity
ts = pd.read_csv(ROOT / "results" / "tau_sensitivity.csv"); a0 = df[(df.arm == "A0") & (df.t == 20)].risk.mean()
fig, ax = plt.subplots(figsize=(3.45, 2.2))
for a, st in (("A2", STY["A2"]), ("A3", STY["A3"])):
    d = ts[ts.arm == a]; ax.plot(d.tau, d.risk, color=st["color"], ls=st["ls"], marker=st["marker"], ms=3.2, lw=1.2, label=st["label"])
ax.axhline(a0, color=C_A0, lw=1.3, label="A0/A1 (no control)")
ax.set_xscale("log"); ax.set_xticks([0.2, 0.35, 0.6, 1, 2]); ax.set_xticklabels(["0.2", "0.35", "0.6", "1.0", "2.0"])
ax.set_xlabel(r"Risk threshold $\tau$"); ax.set_ylabel("Final risk $R_{20}$"); ax.set_ylim(0, 3)
ax.grid(True, lw=0.3, color="0.85"); ax.legend(frameon=False, loc="center right", handlelength=2.6)
for s in ("top", "right"): ax.spines[s].set_visible(False)
save(fig, "fig_tau")

# architecture diagram
fig, ax = plt.subplots(figsize=(3.5, 3.1)); ax.set_xlim(-1.0, 10); ax.set_ylim(0.2, 9.6); ax.axis("off")
# subsystem colours: A provenance (blue), B sensor (green), C risk (orange), D controller (purple), neutral = data/corpus
FC = {"A": "#DCEBF7", "B": "#DDF1E6", "C": "#FCE9D2", "D": "#EADCF0", "N": "#EFEFEF", "L": "#FFF6CC"}
EC = {"A": "#0072B2", "B": "#009E73", "C": "#D55E00", "D": "#7A3E9D", "N": "#555555", "L": "#B8860B"}
def box(x, y, w, h, text, kind="N", fs=6.8):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.15", fc=FC[kind], ec=EC[kind], lw=1.1))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, linespacing=1.2)
def arrow(p, q):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=7, lw=0.9, color="#333333"))
W, H = 2.9, 1.9
xs = [0.2, 3.55, 6.9]; ys = [7.4, 4.2, 1.0]
box(xs[0], ys[0], W, H, "Generative\nmodel $G_t$", "N")
box(xs[1], ys[0], W, H, "Provenance\nencoder (A)", "A")
box(xs[2], ys[0], W, H, "Mixed data\necosystem", "N")
box(xs[2], ys[1], W, H, "Provenance\nverifier and\nledger", "A")
box(xs[1], ys[1], W, H, "Vital-sign\nsensor (B)", "B")
box(xs[0], ys[1], W, H, "Risk estimator\n(C): $R_t=V(\\mathbf{v}_t)$", "C")
box(xs[0], ys[2], W, H, "Controller (D)\nPID / MPC", "D")
box(xs[1], ys[2], W, H, "Actions:\n$\\lambda_{t+1}$, quarantine,\nhalt", "D")
box(xs[2], ys[2], W, H, "Corpus $D_{t+1}$\nrebuilt; train\n$G_{t+1}$", "N")
my = ys[0] + H / 2
arrow((xs[0] + W, my), (xs[1], my)); arrow((xs[1] + W, my), (xs[2], my))
arrow((xs[2] + W / 2, ys[0]), (xs[2] + W / 2, ys[1] + H))
my = ys[1] + H / 2
arrow((xs[2], my), (xs[1] + W, my)); arrow((xs[1], my), (xs[0] + W, my))
arrow((xs[0] + W / 2, ys[1]), (xs[0] + W / 2, ys[2] + H))
my = ys[2] + H / 2
arrow((xs[0] + W, my), (xs[1], my)); arrow((xs[1] + W, my), (xs[2], my))
# dashed feedback path along the left margin: corpus -> next generation of the model
fx = -0.55
ax.plot([xs[2] + W / 2, xs[2] + W / 2], [ys[2], 0.35], color=EC["L"], lw=1.1, ls="--")
ax.plot([xs[2] + W / 2, fx], [0.35, 0.35], color=EC["L"], lw=1.1, ls="--")
ax.plot([fx, fx], [0.35, ys[0] + H / 2], color=EC["L"], lw=1.1, ls="--")
ax.add_patch(FancyArrowPatch((fx, ys[0] + H / 2), (xs[0], ys[0] + H / 2), arrowstyle="-|>", mutation_scale=7, lw=1.1, color=EC["L"], ls="--"))
save(fig, "fig_architecture")
print("figures done:", sorted(p.name for p in OUT.glob("*.png")))
