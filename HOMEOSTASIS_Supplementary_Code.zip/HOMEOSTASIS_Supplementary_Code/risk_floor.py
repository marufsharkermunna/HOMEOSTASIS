"""
risk_floor.py
Estimates the collapse-risk floor caused purely by finite-sample estimation: a model fitted by maximum
likelihood to n_corpus certified-human samples, with no synthetic data at all.  Controlled arms cannot be
expected to fall below this level in the Gaussian testbed.
"""
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).parent))
from homeostasis.vitalsigns import FittedGaussian, LyapunovWeights, collapse_risk, compute_vital_signs

D, N_CORPUS, REPS = 5, 40, 2000
rng = np.random.default_rng(0)
ref = FittedGaussian(np.zeros(D), np.eye(D))
h_star = ref.differential_entropy()
risks = []
for _ in range(REPS):
    model = FittedGaussian.fit(rng.standard_normal((N_CORPUS, D)))
    v = compute_vital_signs(model, model.sample(1000, rng), ref)
    risks.append(collapse_risk(v, h_star, LyapunovWeights()))
print(f"H* = {h_star:.3f} nats; pure-human corpus of n={N_CORPUS}: mean risk {np.mean(risks):.3f} (SD {np.std(risks):.3f})")
