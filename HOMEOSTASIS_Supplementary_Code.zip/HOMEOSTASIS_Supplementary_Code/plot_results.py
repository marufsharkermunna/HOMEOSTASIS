"""
plot_results.py
=================
Generates figures from the REAL data in results/raw_results.csv.
Every curve, error band, and bar in these plots is computed from the
3,000 genuinely-simulated generation-records produced by run_experiment.py.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

RESULTS = Path(__file__).parent / "results"
FIGS = Path(__file__).parent / "figs"
FIGS.mkdir(exist_ok=True)

df = pd.read_csv(RESULTS / "raw_results.csv")

COLORS = {
    "A0": "#B4342A",   # uncontrolled baseline -- red
    "A1": "#C77D22",   # provenance-only -- orange
    "A2": "#2E5C8A",   # control-only -- blue
    "A3": "#1B7F79",   # full HOMEOSTASIS -- teal
    "A4": "#7B4397",   # adversarial -- purple
}
LABELS = {
    "A0": "A0: Uncontrolled baseline",
    "A1": "A1: Provenance-only (observe, no action)",
    "A2": "A2: Control-only (no provenance)",
    "A3": "A3: HOMEOSTASIS (full)",
    "A4": "A4: HOMEOSTASIS + adversarial WM-stripping",
}


def plot_trajectory(metric: str, ylabel: str, title: str, fname: str, logy=False):
    fig, ax = plt.subplots(figsize=(8, 5))
    for arm in ["A0", "A1", "A2", "A3", "A4"]:
        sub = df[df.arm == arm]
        grouped = sub.groupby("t")[metric]
        mean = grouped.mean()
        sem = grouped.std() / np.sqrt(grouped.count())
        t = mean.index.values
        ax.plot(t, mean.values, color=COLORS[arm], linewidth=2.2, label=LABELS[arm])
        ax.fill_between(t, mean.values - 1.96 * sem.values, mean.values + 1.96 * sem.values,
                         color=COLORS[arm], alpha=0.15)
    if logy:
        ax.set_yscale("log")
    ax.set_xlabel("Training generation $t$", fontsize=11, fontweight="bold")
    ax.set_ylabel(ylabel, fontsize=11, fontweight="bold")
    ax.set_title(title, fontsize=12, fontweight="bold", color="#1B2A4A")
    ax.legend(fontsize=8.5, loc="best")
    ax.grid(alpha=0.25)
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)
    plt.tight_layout()
    plt.savefig(FIGS / fname, dpi=220, facecolor="white")
    plt.close()
    print("saved", fname)


plot_trajectory("risk", r"Collapse risk $R(t)=V(v(t))$",
                 "Real Result: Collapse Risk Over 20 Recursive Generations\n(mean +/- 95% CI across 30 seeds per arm)",
                 "result_fig1_risk_trajectory.png")

plot_trajectory("Delta_rep", r"Representational drift $\Delta_{rep}(t)$ (Wasserstein-2)",
                 "Real Result: Representational Drift from Generation-0 Reference",
                 "result_fig2_drift_trajectory.png")

plot_trajectory("tail_coverage", "Tail coverage ratio",
                 "Real Result: Distributional Tail Coverage Over Generations",
                 "result_fig3_tailcoverage_trajectory.png")

plot_trajectory("H_pred", "Predictive entropy $H_{pred}(t)$",
                 "Real Result: Predictive Entropy Over Generations",
                 "result_fig4_entropy_trajectory.png")

# --- Final-generation bar chart with real error bars ---
final_t = df.t.max()
final = df[df.t == final_t]
fig, ax = plt.subplots(figsize=(7.5, 5))
arms = ["A0", "A1", "A2", "A3", "A4"]
means = [final[final.arm == a].risk.mean() for a in arms]
sems = [final[final.arm == a].risk.std() / np.sqrt(final[final.arm == a].risk.count()) for a in arms]
colors = [COLORS[a] for a in arms]
bars = ax.bar(arms, means, yerr=[1.96 * s for s in sems], capsize=6, color=colors,
              edgecolor="black", linewidth=1.1)
ax.axhline(0.35, color="black", linestyle="--", linewidth=1.3, label=r"Risk threshold $\tau$")
ax.set_ylabel(f"Collapse risk $R(t={final_t})$", fontsize=11, fontweight="bold")
ax.set_title(f"Real Result: Final-Generation Collapse Risk by Arm\n"
             f"(n=30 independent seeds per arm; error bars = 95% CI)",
             fontsize=12, fontweight="bold", color="#1B2A4A")
ax.legend(fontsize=9)
for spine in ["top", "right"]:
    ax.spines[spine].set_visible(False)
plt.tight_layout()
plt.savefig(FIGS / "result_fig5_final_risk_bars.png", dpi=220, facecolor="white")
plt.close()
print("saved result_fig5_final_risk_bars.png")

# --- Provenance recall / quarantine rate over generations (provenance-on arms) ---
fig, ax = plt.subplots(figsize=(8, 5))
for arm in ["A1", "A3", "A4"]:
    sub = df[df.arm == arm]
    grouped = sub.groupby("t")["provenance_recall"].mean()
    ax.plot(grouped.index, grouped.values, color=COLORS[arm], linewidth=2.2,
            marker="o", markersize=3.5, label=LABELS[arm])
ax.set_xlabel("Training generation $t$", fontsize=11, fontweight="bold")
ax.set_ylabel("Provenance recall (fraction of synthetic\nsamples correctly verified)", fontsize=10.5, fontweight="bold")
ax.set_title("Real Result: Provenance-Subsystem Recall Over Generations\n"
             "(A4 shows the effect of simulated watermark stripping)",
             fontsize=12, fontweight="bold", color="#1B2A4A")
ax.legend(fontsize=9)
ax.set_ylim(0, 1.05)
ax.grid(alpha=0.25)
for spine in ["top", "right"]:
    ax.spines[spine].set_visible(False)
plt.tight_layout()
plt.savefig(FIGS / "result_fig6_provenance_recall.png", dpi=220, facecolor="white")
plt.close()
print("saved result_fig6_provenance_recall.png")

print("\nAll real-result figures written to", FIGS)
