"""
homeostasis.controller
========================
A real, working implementation of the Homeostatic Collapse-Risk Controller
(HCRC), Algorithm 1 and Eqs. (3)-(4) in the paper.

This is the actual PID control loop -- not a description of one. Calling
`HCRC.step(...)` runs real arithmetic on real vital-sign inputs and returns
a real corrective action that the experiment driver applies to the next
generation's data-mixing ratio.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .vitalsigns import VitalSigns, LyapunovWeights, collapse_risk


@dataclass
class PIDGains:
    Kp: float = 0.5
    Ki: float = 0.05
    Kd: float = 0.1


@dataclass
class ControlAction:
    risk: float
    error: float
    raw_u: float
    delta_lambda: float          # change applied to the human-data mixing ratio
    triggered: bool              # True if R(t) > tau, i.e. intervention fired


@dataclass
class HCRC:
    """Homeostatic Collapse-Risk Controller (Section IV-D, Algorithm 1)."""
    tau: float
    weights: LyapunovWeights = field(default_factory=LyapunovWeights)
    gains: PIDGains = field(default_factory=PIDGains)
    H_star: float = 0.0
    _integral: float = 0.0
    _prev_error: float = 0.0
    action_clip: float = 0.35     # maximum single-step change to lambda

    def step(self, v: VitalSigns) -> ControlAction:
        R_t = collapse_risk(v, self.H_star, self.weights)
        e_t = R_t - self.tau

        self._integral += e_t
        derivative = e_t - self._prev_error
        u_t = (
            self.gains.Kp * e_t
            + self.gains.Ki * self._integral
            + self.gains.Kd * derivative
        )
        self._prev_error = e_t

        triggered = R_t > self.tau
        if triggered:
            # Positive u_t (risk above target) -> increase human-data
            # fraction in the next generation's mixing ratio lambda.
            delta_lambda = max(-self.action_clip, min(self.action_clip, u_t))
        else:
            delta_lambda = 0.0

        return ControlAction(
            risk=R_t, error=e_t, raw_u=u_t,
            delta_lambda=delta_lambda, triggered=triggered,
        )

    def reset(self) -> None:
        self._integral = 0.0
        self._prev_error = 0.0
