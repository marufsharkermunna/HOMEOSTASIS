"""
homeostasis.provenance
=======================
A real, working implementation of the Provenance Substrate described in
Section IV-B (Provenance substrate) of the HOMEOSTASIS paper.

This is NOT a simulation of cryptography -- it uses genuine SHA-256 hashing
and genuine Ed25519 digital signatures (via the `cryptography` library).
Every claim this module makes about verifiability is backed by code that
actually runs the verification.

Design
------
- Each generative model (each "generation" G_t) gets its own Ed25519 keypair,
  standing in for a real model provider's signing key.
- Every generated data record is hashed, chained to the previous record's
  hash (a Merkle-style hash chain -- a simplified, linear special case of a
  Merkle tree, sufficient for a linear generation-by-generation ledger),
  and signed by the generation that produced it.
- A `ProvenanceLedger` stores records and can verify, for any record, that
  (a) its hash chain is intact back to a trusted genesis block, and
  (b) its signature is valid under the claimed generation's public key.
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from typing import Optional

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives import serialization
from cryptography.exceptions import InvalidSignature


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


@dataclass
class GenerationKeys:
    """Keypair standing in for a real model provider's signing identity."""
    generation_index: int
    private_key: Ed25519PrivateKey = field(repr=False)
    public_key: Ed25519PublicKey = field(init=False, repr=False)

    def __post_init__(self):
        self.public_key = self.private_key.public_key()

    @staticmethod
    def generate(generation_index: int) -> "GenerationKeys":
        return GenerationKeys(generation_index, Ed25519PrivateKey.generate())

    def public_bytes(self) -> bytes:
        return self.public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )


@dataclass
class ProvenanceRecord:
    """One entry in the ledger: corresponds to r_t in Eq. (1) of the paper."""
    record_id: str
    generation_index: int
    content_hash: str          # H(x~) -- hash of the (watermarked) content
    prev_hash: str              # h_{t-1}
    this_hash: str = field(init=False)  # h_t = H(h_{t-1} || r_t)
    signature: bytes = field(default=b"", repr=False)
    watermark_intact: bool = True   # simulates whether the statistical
                                     # watermark survived transformations
                                     # (paraphrase / re-encoding / stripping)
    timestamp: float = field(default_factory=time.time)

    def _canonical_payload(self) -> bytes:
        payload = {
            "record_id": self.record_id,
            "generation_index": self.generation_index,
            "content_hash": self.content_hash,
            "prev_hash": self.prev_hash,
        }
        return json.dumps(payload, sort_keys=True).encode("utf-8")

    def compute_hash(self) -> str:
        return sha256_hex(self.prev_hash.encode("utf-8") + self._canonical_payload())

    def sign(self, keys: GenerationKeys) -> None:
        self.this_hash = self.compute_hash()
        self.signature = keys.private_key.sign(self.this_hash.encode("utf-8"))

    def verify_signature(self, public_key: Ed25519PublicKey) -> bool:
        try:
            public_key.verify(self.signature, self.this_hash.encode("utf-8"))
            return True
        except InvalidSignature:
            return False


class ProvenanceLedger:
    """
    An append-only, hash-chained ledger (Section IV-B of the paper).

    genesis_hash anchors the chain to a certified human-sourced corpus
    snapshot, exactly as described in the paper.
    """

    def __init__(self, genesis_data: bytes = b"CERTIFIED_HUMAN_CORPUS_GENESIS"):
        self.genesis_hash = sha256_hex(genesis_data)
        self.records: dict[str, ProvenanceRecord] = {}
        self.chain_order: list[str] = []
        self.public_keys: dict[int, Ed25519PublicKey] = {}

    def register_generation(self, keys: GenerationKeys) -> None:
        self.public_keys[keys.generation_index] = keys.public_key

    def _last_hash(self) -> str:
        if not self.chain_order:
            return self.genesis_hash
        return self.records[self.chain_order[-1]].this_hash

    def append(
        self,
        record_id: str,
        generation_index: int,
        content_hash: str,
        keys: GenerationKeys,
        watermark_intact: bool = True,
    ) -> ProvenanceRecord:
        rec = ProvenanceRecord(
            record_id=record_id,
            generation_index=generation_index,
            content_hash=content_hash,
            prev_hash=self._last_hash(),
            watermark_intact=watermark_intact,
        )
        rec.sign(keys)
        self.records[record_id] = rec
        self.chain_order.append(record_id)
        return rec

    def verify_chain_integrity(self) -> bool:
        """Re-walks the entire chain and confirms every hash link is intact."""
        prev = self.genesis_hash
        for rid in self.chain_order:
            rec = self.records[rid]
            if rec.prev_hash != prev:
                return False
            if rec.compute_hash() != rec.this_hash:
                return False
            prev = rec.this_hash
        return True

    def verify_record(self, record_id: str) -> tuple[bool, Optional[int]]:
        """
        Returns (is_valid, generation_index).
        A record is valid iff: its stored hash is self-consistent, its
        signature checks out under the claimed generation's public key, AND
        its statistical watermark is still intact (a stripped watermark
        means the record cannot be re-identified against the ledger even if
        the metadata itself were technically well-formed -- this mirrors the
        honest, probabilistic framing of Sections IV-B and II-B of the paper).
        """
        rec = self.records.get(record_id)
        if rec is None:
            return False, None
        if rec.compute_hash() != rec.this_hash:
            return False, None
        pub = self.public_keys.get(rec.generation_index)
        if pub is None:
            return False, None
        if not rec.verify_signature(pub):
            return False, None
        if not rec.watermark_intact:
            # Metadata may be technically valid, but per Section II-B's
            # discussion of watermark removal, a stripped/attacked watermark means
            # the *content itself* cannot be reliably matched back to this
            # ledger entry in a real deployment. We treat this as "not
            # verifiable" rather than crash the ledger.
            return False, rec.generation_index
        return True, rec.generation_index

    def __len__(self) -> int:
        return len(self.chain_order)
