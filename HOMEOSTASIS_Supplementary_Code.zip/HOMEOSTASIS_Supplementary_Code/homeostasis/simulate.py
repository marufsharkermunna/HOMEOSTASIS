"""
homeostasis.simulate
======================
The experiment driver: implements the recursive self-consuming training
loop (Section III) and the five experimental arms A0-A4 defined in
Table III of the paper (Section V-B), wiring together:

  - homeostasis.provenance   (real hashing + Ed25519 signatures + ledger)
  - homeostasis.vitalsigns   (real entropy / ECE / Wasserstein-2)
  - homeostasis.controller   (real PID control, HCRC / Algorithm 1)

This produces GENUINE, freshly-computed numbers every run. Nothing here
is a lookup table or a pre-baked result.

Ground-truth world model
-------------------------
D0 ~ N(0, I_d). A finite "certified human reservoir" of N_H iid draws from
D0 stands in for the scarce, non-renewable pool of verified human data
used in the paper's testbed (Section V-A; scarcity of certified
human data). Each generation's training corpus is a mixture of draws from
this fixed reservoir (with replacement -- the reservoir does not grow) and
freshly generated synthetic samples from the previous generation's fitted
model, exactly matching the accumulating/partially-synthetic regime
formalized in Section III of the paper.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

import numpy as np

from .provenance import GenerationKeys, ProvenanceLedger
from .vitalsigns import FittedGaussian, compute_vital_signs, VitalSigns
from .controller import HCRC, PIDGains
from .vitalsigns import LyapunovWeights

ArmName = Literal["A0", "A1", "A2", "A3", "A4"]

ARM_CONFIG = {
    # provenance_on: verification/quarantine actually alters the corpus
    # control_on:    PID controller actually alters lambda_t
    # wm_survival:   probability a synthetic sample's watermark is still
    #                intact & verifiable at ingestion time
    "A0": dict(provenance_on=False, control_on=False, wm_survival=0.95),
    "A1": dict(provenance_on=True,  control_on=False, wm_survival=0.95),
    "A2": dict(provenance_on=False, control_on=True,  wm_survival=0.95),
    "A3": dict(provenance_on=True,  control_on=True,  wm_survival=0.95),
    "A4": dict(provenance_on=True,  control_on=True,  wm_survival=0.40),
}


@dataclass
class GenerationRecord:
    arm: str
    seed: int
    t: int
    H_pred: float
    ECE: float
    Delta_rep: float
    risk: float
    lam: float
    tail_coverage: float
    provenance_recall: float
    provenance_fpr: float
    quarantine_rate: float
    n_corpus: int


def _tail_coverage(model: FittedGaussian, ref: FittedGaussian,
                    rng: np.random.Generator, n_probe: int = 4000,
                    maha_lo: float = 2.5, maha_hi: float = 3.5) -> float:
    """
    Draws n_probe points from the ORIGINAL reference distribution's tail
    shell (Mahalanobis distance in [maha_lo, maha_hi] under the reference
    covariance), then measures the fraction of those genuinely rare points
    that the CURRENT fitted model still assigns non-negligible density to
    (density above 1% of the reference's own density at that shell).
    This directly operationalizes "loss of distributional tails"
    (Section V-C, tail coverage) as a real, computable number.
    """
    d = ref.mean.shape[0]
    L = np.linalg.cholesky(ref.cov)
    # sample directions uniformly on the sphere, radius uniform in [lo,hi]
    dirs = rng.normal(size=(n_probe, d))
    dirs /= np.linalg.norm(dirs, axis=1, keepdims=True)
    radii = rng.uniform(maha_lo, maha_hi, size=n_probe)
    tail_points = ref.mean + (dirs * radii[:, None]) @ L.T

    def log_density(pt_batch, gm: FittedGaussian):
        diff = pt_batch - gm.mean
        prec = np.linalg.inv(gm.cov)
        sign, logdet = np.linalg.slogdet(gm.cov)
        maha = np.einsum('ij,jk,ik->i', diff, prec, diff)
        return -0.5 * (d * np.log(2 * np.pi) + logdet + maha)

    ref_logdens = log_density(tail_points, ref)
    cur_logdens = log_density(tail_points, model)
    covered = cur_logdens > (ref_logdens + np.log(0.01))
    return float(covered.mean())


def run_single(arm: ArmName, seed: int, T: int = 15, d: int = 5,
               n_corpus: int = 200, n_human_reservoir: int = 4000,
               lambda_init: float = 0.15, tau: float = 1.0,
               H_star: float | None = None) -> list[GenerationRecord]:
    """Runs ONE full recursive-training trajectory for ONE arm/seed."""
    cfg = ARM_CONFIG[arm]
    rng = np.random.default_rng(seed)

    ref_model = FittedGaussian(mean=np.zeros(d), cov=np.eye(d))
    if H_star is None:
        H_star = ref_model.differential_entropy()

    human_reservoir = rng.multivariate_normal(np.zeros(d), np.eye(d), size=n_human_reservoir)

    ledger = ProvenanceLedger()
    gen0_keys = GenerationKeys.generate(0)
    ledger.register_generation(gen0_keys)

    controller = HCRC(
        tau=tau,
        weights=LyapunovWeights(w1=1.0, w2=1.0, w3=1.0),
        gains=PIDGains(Kp=0.5, Ki=0.05, Kd=0.1),
        H_star=H_star,
    )

    lam = lambda_init
    current_model = ref_model  # generation 0 "model" == the true human distribution
    records: list[GenerationRecord] = []

    for t in range(1, T + 1):
        n_human = int(round(lam * n_corpus))
        n_synth = n_corpus - n_human

        human_idx = rng.integers(0, n_human_reservoir, size=n_human)
        human_samples = human_reservoir[human_idx]

        synth_samples = current_model.sample(n_synth, rng) if n_synth > 0 else np.empty((0, d))

        # --- Provenance tagging of synthetic samples ---
        keys_t = GenerationKeys.generate(t)
        ledger.register_generation(keys_t)
        wm_intact_flags = rng.random(n_synth) < cfg["wm_survival"]
        record_ids = []
        for i in range(n_synth):
            rid = f"{arm}-{seed}-t{t}-{i}"
            content_hash = f"hash-of-sample-{rid}"
            ledger.append(rid, t, content_hash, keys_t, watermark_intact=bool(wm_intact_flags[i]))
            record_ids.append(rid)

        # --- Verification (logging/attribution -- happens whenever
        #     provenance_on, REGARDLESS of whether control acts on it).
        #     This is what lets A1 "attribute after the fact" without
        #     preventing anything. ---
        n_quarantined = 0
        n_true_synth_detected = 0
        flagged_bad = np.zeros(n_synth, dtype=bool)
        if cfg["provenance_on"]:
            for i, rid in enumerate(record_ids):
                valid, _ = ledger.verify_record(rid)
                if valid:
                    n_true_synth_detected += 1
                else:
                    flagged_bad[i] = True
            recall = n_true_synth_detected / n_synth if n_synth > 0 else 1.0
            fpr = 0.0  # human samples never carry a spurious synthetic record here
        else:
            recall = float("nan")
            fpr = float("nan")

        # --- Quarantine ACTION: only actually removes samples from the
        #     training corpus when provenance verification AND the
        #     controller are BOTH active (A3 / A4). This is what correctly
        #     isolates "provenance-only" (A1, observe but do not act) from
        #     "provenance + control" (A3/A4, observe AND act). ---
        if cfg["provenance_on"] and cfg["control_on"]:
            n_quarantined = int(flagged_bad.sum())
            kept_synth = synth_samples[~flagged_bad]
            n_missing = n_synth - kept_synth.shape[0]
            if n_missing > 0:
                backfill_idx = rng.integers(0, n_human_reservoir, size=n_missing)
                backfill = human_reservoir[backfill_idx]
                corpus = np.vstack([human_samples, kept_synth, backfill])
            else:
                corpus = np.vstack([human_samples, kept_synth]) if kept_synth.shape[0] else human_samples
            qrate = n_quarantined / n_synth if n_synth > 0 else 0.0
        else:
            # No corpus-altering action: use the corpus exactly as originally
            # mixed (provenance may still have been verified/logged above).
            corpus = np.vstack([human_samples, synth_samples]) if n_synth > 0 else human_samples
            qrate = 0.0

        # --- Fit this generation's model on the (possibly purified) corpus ---
        current_model = FittedGaussian.fit(corpus)

        # --- Vital signs & risk ---
        probe = current_model.sample(1000, rng)
        v: VitalSigns = compute_vital_signs(current_model, probe, ref_model)
        tail_cov = _tail_coverage(current_model, ref_model, rng)

        action = controller.step(v)

        records.append(GenerationRecord(
            arm=arm, seed=seed, t=t,
            H_pred=v.H_pred, ECE=v.ECE, Delta_rep=v.Delta_rep,
            risk=action.risk, lam=lam, tail_coverage=tail_cov,
            provenance_recall=recall, provenance_fpr=fpr,
            quarantine_rate=qrate, n_corpus=corpus.shape[0],
        ))

        # --- Update lambda for next generation (only if control_on) ---
        if cfg["control_on"]:
            lam = float(np.clip(lam + action.delta_lambda, 0.0, 1.0))
        # else lam stays fixed at lambda_init

    return records
