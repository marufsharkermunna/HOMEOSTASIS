# HOMEOSTASIS -- Reference Implementation (MVP)

A real, runnable implementation of the core mechanisms from the paper
*"HOMEOSTASIS: Closed-Loop Cryptographic Provenance and Homeostatic
Control for Detecting and Mitigating Generative Model Collapse"* (Md. Maruf Sharker Munna, University of
Liberal Arts Bangladesh).

**Read `RESULTS.md` for the actual findings, including an honest negative
result.** This README is about how to run the code yourself.

## What is really here

| Module | What it really does |
|---|---|
| `homeostasis/provenance.py` | Real SHA-256 hashing + real Ed25519 digital signatures (via the `cryptography` library) + a real hash-chained (Merkle-style) append-only ledger. Not simulated. |
| `homeostasis/vitalsigns.py` | Real differential entropy, a real (non-circular, Bayesian) calibration-error test, and the real closed-form 2-Wasserstein distance between fitted Gaussians. |
| `homeostasis/controller.py` | A real PID control loop (Homeostatic Collapse-Risk Controller / HCRC, Algorithm 1 of the paper). |
| `homeostasis/simulate.py` | The recursive self-consuming training loop, implementing all 5 experimental arms (A0-A4) from Table III of the paper on a Gaussian testbed. |
| `run_experiment.py` | Runs the full protocol: 5 arms x 30 seeds x 20 generations = 3,000 genuinely-computed generation-records. Takes ~15 seconds on a laptop CPU. |
| `analyze.py` | Real statistical validation: Shapiro-Wilk -> paired t-test/Wilcoxon, bootstrap Cohen's d with 95% CI, Benjamini-Hochberg FDR correction. Implements Section V-E (Statistical analysis) of the paper. |
| `plot_results.py` | Generates all figures in `figs/result_fig*.png` directly from `results/raw_results.csv`. |
| `tests/` | 18 unit tests (`python3 -m unittest discover tests -v`) covering the cryptographic ledger (tamper detection, wrong-key rejection, stripped-watermark handling) and the controller (trigger logic, clipping, integral accumulation). |

## Quickstart

```bash
pip install -r requirements.txt

# 1. Run the unit tests (should show "OK", 18 tests)
python3 -m unittest discover tests -v

# 2. Run the full experiment (writes results/raw_results.csv)
python3 run_experiment.py

# 3. Run the statistical validation (writes results/statistical_tests.json)
python3 analyze.py

# 4. Generate the result figures (writes figs/result_fig*.png)
python3 plot_results.py
```

All four steps together take under a minute on a normal laptop CPU. No
GPU is required. Re-running will use fresh randomness unless you fix seeds
(the experiment already uses fixed seeds 0..29 per arm for reproducibility
of the *specific* numbers reported in `RESULTS.md`; changing
`N_SEEDS`/`T_GENERATIONS`/`N_CORPUS` in `run_experiment.py` will change the
numbers but not, in our testing, the qualitative pattern).

## Honesty notes

- This is a Gaussian testbed, not a language-model or diffusion-model
  experiment. See `RESULTS.md` Section 1 for exactly what this does and
  does not demonstrate.
- One of the paper's central hypotheses (provenance + control jointly
  beats control alone) is **not** supported by this experiment. This is
  reported, not hidden -- see `RESULTS.md` Section 4.
- The adversarial arm (A4)'s threat model is limited (see `RESULTS.md`
  Section 5) and should not be read as a validated robustness guarantee.

## Project layout

```
HOMEOSTASIS_Supplementary_Code/
├── homeostasis/          # the actual library
│   ├── provenance.py
│   ├── vitalsigns.py
│   ├── controller.py
│   └── simulate.py
├── tests/                 # unit tests (real, run them)
├── run_experiment.py       # produces results/raw_results.csv
├── analyze.py               # produces results/statistical_tests.json
├── plot_results.py           # produces figs/result_fig*.png
├── results/                   # generated CSV + JSON (real data)
├── figs/                        # created by plot_results.py
├── paper_figs/                 # created by make_paper_figures.py
├── RESULTS.md                    # the actual findings, written honestly
├── requirements.txt
└── README.md                      # this file
```

## Added for the IEEE paper

| File | Purpose |
|---|---|
| `sensitivity_tau.py` | Re-runs A2/A3 for tau in {0.2, 0.35, 0.6, 1.0, 2.0}; writes `results/tau_sensitivity.csv` |
| `risk_floor.py` | Risk floor from finite-sample estimation (pure-human corpus, n=40) |
| `make_paper_figures.py` | Colour figures used in the paper (writes `paper_figs/` as PDF and 600 dpi PNG) |

Re-running `run_experiment.py` and `analyze.py` reproduces `raw_results.csv` byte for byte (fixed seeds).

## License

Released under the MIT License (see `LICENSE`).
