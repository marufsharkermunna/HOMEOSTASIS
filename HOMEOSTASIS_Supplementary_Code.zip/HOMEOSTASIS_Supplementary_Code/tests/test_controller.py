"""
Real unit tests for homeostasis.vitalsigns and homeostasis.controller.
Run with: python3 -m unittest tests.test_controller -v
"""
import sys
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

from homeostasis.vitalsigns import (
    FittedGaussian, wasserstein2_gaussian, expected_calibration_error,
    compute_vital_signs, collapse_risk, LyapunovWeights,
)
from homeostasis.controller import HCRC, PIDGains


class TestVitalSigns(unittest.TestCase):

    def test_wasserstein_zero_for_identical_distributions(self):
        g = FittedGaussian(mean=np.zeros(3), cov=np.eye(3))
        self.assertAlmostEqual(wasserstein2_gaussian(g, g), 0.0, places=6)

    def test_wasserstein_positive_for_different_means(self):
        g1 = FittedGaussian(mean=np.zeros(2), cov=np.eye(2))
        g2 = FittedGaussian(mean=np.array([3.0, 0.0]), cov=np.eye(2))
        w = wasserstein2_gaussian(g1, g2)
        self.assertAlmostEqual(w, 3.0, places=4)  # pure mean-shift case is exact

    def test_wasserstein_symmetric(self):
        rng = np.random.default_rng(0)
        A = rng.normal(size=(5, 3))
        B = rng.normal(size=(5, 3))
        g1 = FittedGaussian.fit(A)
        g2 = FittedGaussian.fit(B)
        self.assertAlmostEqual(wasserstein2_gaussian(g1, g2),
                                wasserstein2_gaussian(g2, g1), places=6)

    def test_entropy_decreases_with_shrinking_variance(self):
        wide = FittedGaussian(mean=np.zeros(2), cov=np.eye(2))
        narrow = FittedGaussian(mean=np.zeros(2), cov=0.01 * np.eye(2))
        self.assertGreater(wide.differential_entropy(), narrow.differential_entropy())

    def test_ece_is_low_when_reference_equals_current(self):
        rng = np.random.default_rng(1)
        ref = FittedGaussian(mean=np.zeros(2), cov=np.eye(2))
        probe = rng.multivariate_normal(np.zeros(2), np.eye(2), size=5000)
        ece = expected_calibration_error(ref, probe, n_bins=10)
        self.assertLess(ece, 0.08)  # well-specified classifier should be well calibrated

    def test_collapse_risk_zero_at_healthy_equilibrium(self):
        v_healthy = compute_vital_signs.__wrapped__ if False else None
        from homeostasis.vitalsigns import VitalSigns
        v = VitalSigns(H_pred=5.0, ECE=0.0, Delta_rep=0.0)
        r = collapse_risk(v, H_star=5.0, weights=LyapunovWeights())
        self.assertEqual(r, 0.0)

    def test_collapse_risk_increases_with_drift(self):
        from homeostasis.vitalsigns import VitalSigns
        weights = LyapunovWeights()
        v_low = VitalSigns(H_pred=5.0, ECE=0.05, Delta_rep=0.1)
        v_high = VitalSigns(H_pred=3.0, ECE=0.3, Delta_rep=2.0)
        r_low = collapse_risk(v_low, H_star=5.0, weights=weights)
        r_high = collapse_risk(v_high, H_star=5.0, weights=weights)
        self.assertGreater(r_high, r_low)


class TestHCRC(unittest.TestCase):

    def test_no_action_when_risk_below_threshold(self):
        from homeostasis.vitalsigns import VitalSigns
        ctrl = HCRC(tau=10.0, H_star=5.0)  # very high threshold, won't trigger
        v = VitalSigns(H_pred=5.0, ECE=0.01, Delta_rep=0.05)
        action = ctrl.step(v)
        self.assertFalse(action.triggered)
        self.assertEqual(action.delta_lambda, 0.0)

    def test_action_triggers_when_risk_exceeds_threshold(self):
        from homeostasis.vitalsigns import VitalSigns
        ctrl = HCRC(tau=0.01, H_star=5.0)  # very low threshold, will trigger
        v = VitalSigns(H_pred=3.0, ECE=0.2, Delta_rep=1.0)
        action = ctrl.step(v)
        self.assertTrue(action.triggered)
        self.assertGreater(action.delta_lambda, 0.0)  # should push toward more human data

    def test_action_is_clipped(self):
        from homeostasis.vitalsigns import VitalSigns
        ctrl = HCRC(tau=0.001, H_star=100.0, action_clip=0.2)
        v = VitalSigns(H_pred=0.0, ECE=1.0, Delta_rep=50.0)  # extreme risk
        action = ctrl.step(v)
        self.assertLessEqual(abs(action.delta_lambda), 0.2)

    def test_integral_term_accumulates_across_steps(self):
        from homeostasis.vitalsigns import VitalSigns
        ctrl = HCRC(tau=0.01, H_star=5.0, gains=PIDGains(Kp=0.0, Ki=1.0, Kd=0.0))
        v = VitalSigns(H_pred=4.9, ECE=0.0, Delta_rep=0.05)
        a1 = ctrl.step(v)
        a2 = ctrl.step(v)
        # with pure integral control and constant positive error, the raw
        # control signal must grow in magnitude on the second step
        self.assertGreater(abs(a2.raw_u), abs(a1.raw_u))


if __name__ == "__main__":
    unittest.main()
