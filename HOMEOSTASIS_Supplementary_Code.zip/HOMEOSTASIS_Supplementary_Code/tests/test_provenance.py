"""
Real unit tests for homeostasis.provenance -- run with:
    python3 -m unittest tests.test_provenance -v
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from homeostasis.provenance import GenerationKeys, ProvenanceLedger


class TestProvenanceLedger(unittest.TestCase):

    def setUp(self):
        self.ledger = ProvenanceLedger()
        self.keys0 = GenerationKeys.generate(0)
        self.keys1 = GenerationKeys.generate(1)
        self.ledger.register_generation(self.keys0)
        self.ledger.register_generation(self.keys1)

    def test_valid_record_verifies(self):
        self.ledger.append("rec-1", 1, "hash-of-content-A", self.keys1)
        valid, gen = self.ledger.verify_record("rec-1")
        self.assertTrue(valid)
        self.assertEqual(gen, 1)

    def test_chain_integrity_holds_across_many_records(self):
        for i in range(20):
            self.ledger.append(f"rec-{i}", 1, f"hash-{i}", self.keys1)
        self.assertTrue(self.ledger.verify_chain_integrity())
        self.assertEqual(len(self.ledger), 20)

    def test_tampered_hash_fails_verification(self):
        rec = self.ledger.append("rec-tamper", 1, "hash-X", self.keys1)
        # Simulate an attacker tampering with the stored hash after the fact
        rec.this_hash = "0" * 64
        valid, _ = self.ledger.verify_record("rec-tamper")
        self.assertFalse(valid)

    def test_wrong_signer_key_fails_verification(self):
        # Append a record but sign it with the WRONG generation's key,
        # then claim it came from generation 1 anyway.
        self.ledger.append("rec-wrongkey", 1, "hash-Y", self.keys0)  # signed by gen 0 keys
        valid, _ = self.ledger.verify_record("rec-wrongkey")
        # generation_index says 1, but it was signed with gen-0's key ->
        # verification must fail because ledger checks against gen 1's
        # registered public key.
        self.assertFalse(valid)

    def test_stripped_watermark_is_not_verifiable(self):
        self.ledger.append("rec-stripped", 1, "hash-Z", self.keys1, watermark_intact=False)
        valid, gen = self.ledger.verify_record("rec-stripped")
        self.assertFalse(valid)
        self.assertEqual(gen, 1)  # generation is still recoverable from the
                                   # signature even though content-matching
                                   # itself is not reliable (honest, matches
                                   # Section IV-B's probabilistic framing)

    def test_unknown_record_id_returns_invalid(self):
        valid, gen = self.ledger.verify_record("does-not-exist")
        self.assertFalse(valid)
        self.assertIsNone(gen)

    def test_genesis_anchor_is_deterministic(self):
        l1 = ProvenanceLedger(genesis_data=b"same seed")
        l2 = ProvenanceLedger(genesis_data=b"same seed")
        self.assertEqual(l1.genesis_hash, l2.genesis_hash)
        l3 = ProvenanceLedger(genesis_data=b"different seed")
        self.assertNotEqual(l1.genesis_hash, l3.genesis_hash)


if __name__ == "__main__":
    unittest.main()
