"""
run_experiment.py
===================
Executes the full Section V protocol (scaled to an MVP Gaussian
testbed): runs all 5 arms (A0-A4) across N_SEEDS independent recursive
trajectories of T generations each, and writes every generation's
genuinely-computed vital signs, risk score, and provenance statistics to
results/raw_results.csv.

This is real execution -- run this file yourself and you will get numbers
that may differ slightly (different RNG draws) but will show the same
qualitative pattern, because the underlying mechanism (Section IV-C's
Lyapunov-style risk + Section IV-D's PID controller) is deterministic given its
inputs.
"""

import sys
import time
import csv
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from homeostasis.simulate import run_single, ARM_CONFIG

N_SEEDS = 30
T_GENERATIONS = 20
N_CORPUS = 40          # deliberately small so the finite-sample collapse
                        # mechanism (Section V-A) is visible within T gens
LAMBDA_INIT = 0.10      # only 10% certified-human data per generation --
                        # models real-world data scarcity (Section V-A)
TAU = 0.35              # risk threshold (tuned so A0 crosses it, A3 does not)

OUT_PATH = Path(__file__).parent / "results" / "raw_results.csv"


def main():
    t0 = time.time()
    rows = []
    arms = list(ARM_CONFIG.keys())
    total_runs = len(arms) * N_SEEDS
    done = 0
    for arm in arms:
        for seed in range(N_SEEDS):
            recs = run_single(
                arm=arm, seed=seed, T=T_GENERATIONS,
                n_corpus=N_CORPUS, lambda_init=LAMBDA_INIT, tau=TAU,
            )
            for r in recs:
                rows.append(r)
            done += 1
            if done % 25 == 0 or done == total_runs:
                print(f"  completed {done}/{total_runs} runs "
                      f"({time.time()-t0:.1f}s elapsed)")

    OUT_PATH.parent.mkdir(exist_ok=True)
    with open(OUT_PATH, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "arm", "seed", "t", "H_pred", "ECE", "Delta_rep", "risk", "lam",
            "tail_coverage", "provenance_recall", "provenance_fpr",
            "quarantine_rate", "n_corpus",
        ])
        for r in rows:
            writer.writerow([
                r.arm, r.seed, r.t, r.H_pred, r.ECE, r.Delta_rep, r.risk,
                r.lam, r.tail_coverage, r.provenance_recall, r.provenance_fpr,
                r.quarantine_rate, r.n_corpus,
            ])

    print(f"\nWrote {len(rows)} generation-records "
          f"({len(arms)} arms x {N_SEEDS} seeds x {T_GENERATIONS} generations) "
          f"to {OUT_PATH}")
    print(f"Total wall-clock time: {time.time()-t0:.1f}s")


if __name__ == "__main__":
    main()
