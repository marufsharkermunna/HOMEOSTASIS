"""
sensitivity_tau.py
Checks how sensitive the A3-vs-A2 and A2/A3-vs-A0 conclusions are to the
risk threshold tau, which the main experiment set to 0.35 after inspecting
the uncontrolled baseline.  Writes results/tau_sensitivity.csv.
"""
import sys
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).parent))
from homeostasis.simulate import run_single

N_SEEDS, T, N_CORPUS, LAM0 = 30, 20, 40, 0.10
TAUS = [0.20, 0.35, 0.60, 1.00, 2.00]
rows = []
for tau in TAUS:
    fin = {}
    for arm in ["A2", "A3"]:
        fin[arm] = [run_single(arm, s, T=T, n_corpus=N_CORPUS, lambda_init=LAM0, tau=tau)[-1]
                    for s in range(N_SEEDS)]
    for arm in ["A2", "A3"]:
        r = fin[arm]
        rows.append(dict(tau=tau, arm=arm,
                         risk=np.mean([x.risk for x in r]),
                         tail_coverage=np.mean([x.tail_coverage for x in r]),
                         final_lambda=np.mean([x.lam for x in r])))
    d = np.array([a.risk - b.risk for a, b in zip(fin["A3"], fin["A2"])])
    rows.append(dict(tau=tau, arm="A3-A2", risk=d.mean(),
                     tail_coverage=np.nan, final_lambda=d.mean() / d.std(ddof=1)))  # last col = paired d here
out = pd.DataFrame(rows)
out.to_csv(Path(__file__).parent / "results" / "tau_sensitivity.csv", index=False)
print(out.round(3).to_string(index=False))
